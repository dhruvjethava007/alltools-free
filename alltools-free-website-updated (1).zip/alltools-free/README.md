# AllTools Free

A zero-cost starter website for browser-based utilities. Most tools run locally in the browser and do not need a paid API.

## Included
- QR Code Generator (uses QRCode.js from a CDN; internet required)
- Image Compressor (Canvas API; local processing)
- Word Counter
- Percentage Calculator
- Text Case Converter
- Age Calculator
- GST Calculator
- Print/save text as PDF using the browser print dialog
- English, Gujarati and Hindi labels for the main homepage
- Responsive layout, SEO metadata, About, Contact, Privacy Policy and Terms pages

## Run locally
Open `index.html` in a modern browser. QR generation requires internet access to load the QRCode.js CDN script.

## Publish at no cost
1. Create a GitHub account and a new public repository.
2. Upload `index.html` and this README.
3. In repository Settings, open Pages.
4. Choose deploy from the `main` branch and `/ (root)`, then save.
5. Wait for GitHub Pages to publish and open the generated URL.

Important: GitHub Pages is intended for static sites and is not for running an e-commerce or SaaS backend. Check the current GitHub Pages terms before adding commercial features or advertising. If you intend to monetize with ads, select a host whose terms allow your intended use.
A custom domain is optional and usually costs money; use the free host subdomain at first.

## Before launch
- Replace `your-email@example.com` with a monitored contact address.
- Review privacy and terms pages against the actual hosting, CDN, analytics and ad providers used.
- Add a sitemap.xml and robots.txt if appropriate after choosing the final public URL.
- Add ad code only after the ad network approves the site and only in compliance with its policies.
- The starter does not guarantee AdSense approval or income.
- QR code library is loaded from cdnjs. For fully offline operation, download a properly licensed copy of QRCode.js and serve it locally.
- PDF feature uses browser Print > Save as PDF; it is not a full PDF merge/split/conversion engine.
